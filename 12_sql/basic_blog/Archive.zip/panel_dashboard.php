<?php include 'template/header.php'; ?>
<?php include 'template/panel_session.php'; ?>
<?php include 'template/panel_nav.php'; ?>

<pre><?php print_r($_SESSION['user']) ?></pre>


<?php include 'template/footer.php'; ?>


