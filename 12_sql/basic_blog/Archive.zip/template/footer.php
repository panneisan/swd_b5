<script src="<?php assets('js/jquery-3.3.1.min.js') ?>"></script>
<script src="<?php assets('js/popper.min.js') ?>"></script>
<script src="<?php assets('js/bootstrap.js') ?>"></script>
<script src="<?php assets('data_table/jquery.dataTables.min.js');?>"></script>
<script src="<?php assets('data_table/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php assets('js/app.js') ?>"></script>
</body>
</html>