<?php include "core/base.php";?>
<?php session_start(); ?>
<?php include "core/functions.php";?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php assets('css/bootstrap.css') ?>">
    <link rel="stylesheet" href="<?php assets('css/font-awesome.css') ?>">
    <link rel="stylesheet" href="<?php assets('data_table/dataTables.bootstrap4.min.css'); ?>">
    <link rel="stylesheet" href="<?php assets('css/style.css') ?>">
</head>
<body>

